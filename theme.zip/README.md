# Theme
JANGAN DIJUAL BELAKAN YE BWANG !!!
BUTUH LICENSE/PW CHAT TELE GUA
>> t.me/fadhost <<

Comand Run Install Thema

bash <(curl https://raw.githubusercontent.com/gitfdil1248/thema/main/install.sh)
